import cv2
import threading
import time
from pyVHR.extraction.utils import *



class VideoCapture:
    # bufferless VideoCapture
    def __init__(self, name, sharedData, frameGenerator, fps=None, sleep=False, resize=True):
        #self.cap = cv2.VideoCapture(name)
        self.sleep = sleep                      #fake delay from Params
        self.resize = resize                    #
        self.fps = None         
        if fps is not None:
            #self.cap.set(cv2.CAP_PROP_FPS, fps)
            self.fps = fps                      #fixed or real fps from Params
        self.sd = sharedData
        self.fg = frameGenerator
        
        self.t = threading.Thread(target=self._captureFrames)
        
        self.t.daemon = False                   # when process ends all deamon will be killed
        self.t.start()                          # starts thread for active video capturing. See _reader method.

    # read frames as soon as they are available
    def _captureFrames(self):
        while True:
            if self.fg.cap_readed is not None:
                if not self.sd.q_stop_cap.empty():
                    self.sd.q_stop_cap.get()
                    self.sd.q_stop.put(0)  
                    self.sd.q_frames.put(0)
                    break 
            
                ret, frame =  self.fg.cap_readed

                if not ret:  
                    self.sd.q_stop.put(0)  
                    self.sd.q_frames.put(0)  
                    break
        
                if self.resize:
                    h, w = frame.shape[0], frame.shape[1]
                    if h != 480 or w != 640:
                        frame = cv2.resize(frame, (640, int(640*h/w)),
                                        interpolation=cv2.INTER_NEAREST)
                        
                self.sd.q_frames.put(frame)
                if self.sleep and self.fps is not None:
                    time.sleep(self.fps / 1000.0)
