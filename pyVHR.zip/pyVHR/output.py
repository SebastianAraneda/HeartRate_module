import threading
import time

class Output:
    def __init__(self):
        self.frames = None
        self.bpm = None
        self.active = False
        self.t = threading.Thread(target=self._outing)
        self.t.daemon = False
        self.t.start()
        
    def _outing(self):
        prev_time = time.time()
        while True:
            dt = time.time() - prev_time
            if self.frames is not None:
                self.active = True
            if dt > 0.5: 
                print(self.active)                
                prev_time = time.time()
            

