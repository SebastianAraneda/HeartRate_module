import cv2
import threading
from pyVHR.extraction.utils import *

# This class simulates that fastApi generates as frames, to be tested in
# videoCapture new method captureFrames()

class FrameGenerator:
    def __init__(self):
        self.cap_readed = None
        self.video_file = '../bpm_v2/alex/alex_rotation/cv_camera_sensor_stream_handler.avi'
        self.fps = 25
        self.t = threading.Thread(target=self._generate)
        self.t.daemon = False                   # when process ends all deamon will be killed
        self.t.start()
    
    def _generate(self):
        counter = 0
        replay = 0
        cap = cv2.VideoCapture(self.video_file)
        while True:
            self.cap_readed = cap.read()
            if not self.cap_readed[0]:
                replay = replay + 1
                cap = cv2.VideoCapture(self.video_file)
                self.cap_readed = cap.read()
            if replay >= 1:
                break
            #print(len(frame), len(frame[0]), frame[0][0])
            counter = counter+1
        print(replay, counter)
        cap.release()
    