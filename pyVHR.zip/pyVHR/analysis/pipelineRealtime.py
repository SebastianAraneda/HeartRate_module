import configparser
import ast
import numpy as np
import plotly.graph_objects as go
from pyVHR.extraction.sig_processing import *
from pyVHR.extraction.sig_extraction_methods import *
from pyVHR.extraction.skin_extraction_methods import *
from pyVHR.BVP.BVP import *
from pyVHR.BPM.BPM import *
from pyVHR.BVP.methods import *
from pyVHR.BVP.filters import *

from pyVHR.realtime.VHRroutine import *
from pyVHR.realtime.params import Params
import threading
import time

from inspect import getmembers, isfunction
import os.path


class PipelineRealtime():
    """ 
    This class runs a pipeline just for using real time config.
    """

    def __init__(self):
        pass

    def run_on_camera(self, 
            videoFileName,
            framer = None,
            cuda=True, 
            roi_method='convexhull', 
            roi_approach='holistic', 
            method='cupy_POS', 
            bpm_type='welch', 
            pre_filt=False, 
            post_filt=True, 
            verb=False,
            fps = None,
            frame = None):


        bpm_plot = []
        bpm_save = []
        bpm_plot_max = 60
        image = None
        original_image = None
        skin_image = None
        patches_image = None
        vhr_t = None
        sd = SharedData()
        

        type_options = ['mean', 'median']
        patches_options = ['squares','rects']

        rects_dim_sim = "[[],]"
        skin_color_low_threshold = "75"
        skin_color_high_threshold = "230"
        sig_color_low_threshold = "75"
        sig_color_high_threshold = "230"
        
        visualizeskintrue_sim = False
        visualizeldmkstrue_sim = False
        visualizepatchestrue_sim = False
        visualizeldmksnumtrue_sim = False
        fontSize = "0.3"  ## to correct: allways False when isnumeric()
        fontcolor = '(255, 0, 0, 255)'

        color_low_threshold = "75"
        color_high_threshold = "230"

        #event = ''
        event = '-APPLY-'

        bpm_plot_max = 10
        event_manager = 0

        while True:
            
            if event_manager >= 100:
                event = 'Exit'

            event_manager = event_manager + 1
            #if event_manager % 1000 == 0:
            #    print(f"Iteraciones = {event_manager}" + ", event: " + event)

            
            if event in (None, 'Exit', 'Stop'):
                sd.q_stop_cap.put(0)  # stop cap, it will stop VHR model thread
                sd.q_stop.put(0)  # stop VHR model thread if cap can't
                vhr_t.join()
                vhr_t = None
                sd = SharedData()
                sd = None
                
            
            # BPM plot
            if not sd.q_bpm.empty():
                bpm = sd.q_bpm.get()
                bpm_plot.append(bpm)
                bpm_save.append(bpm)

                if len(bpm_plot) >= bpm_plot_max:
                    bpm_plot = bpm_plot[1:]
                fig = go.Figure()
                fig.add_trace(go.Scatter(x=np.arange(0, len(bpm_plot), Params.stride), y=np.array(bpm_plot),
                                        mode='lines+markers',
                                        name='lines+markers'))
                fig.update_layout(
                    autosize=False,
                    width=600,
                    height=400,
                    margin=dict(l=1, r=1, b=1, t=1, pad=1),
                    paper_bgcolor="LightSteelBlue",
                )
                img_bytes = fig.to_image(format="png")
                    
                
            if event == '-APPLY-':
                if videoFileName == '':
                    Params.videoFileName = 0
                else:
                    Params.videoFileName = videoFileName
                if videoFileName.isnumeric():
                    Params.videoFileName = int(videoFileName)
                    Params.fake_delay = False
                else:
                    Params.fake_delay = True
                
                Params.cuda = cuda
                Params.fps_fixed = fps
                Params.rPPG_method = method
                Params.skin_extractor = roi_method
                Params.approach = roi_approach
                Params.type = type_options[0]
                Params.patches = patches_options[0]
                
                try:
                    Params.rects_dims = ast.literal_eval(rects_dim_sim)
                    # Default if len is not the same
                    if len(Params.rects_dims) != len(Params.landmarks_list):
                        new_rect_dim = []
                        for i in range(len(Params.landmarks_list)):
                            new_rect_dim.append(
                                [Params.squares_dim, Params.squares_dim])
                        Params.rects_dims = new_rect_dim
                except:
                    # Default if parameter is wrong
                    new_rect_dim = []
                    for i in range(len(Params.landmarks_list)):
                        new_rect_dim.append(
                            [Params.squares_dim, Params.squares_dim])
                    Params.rects_dims = new_rect_dim

                if skin_color_low_threshold.isnumeric():
                    Params.skin_color_low_threshold = int(
                        skin_color_low_threshold) if int(skin_color_low_threshold) >= 0 and int(skin_color_low_threshold) <= 255 else 2


                if skin_color_high_threshold.isnumeric():
                    Params.skin_color_high_threshold = int(
                        skin_color_high_threshold) if int(skin_color_high_threshold) >= 0 and int(skin_color_high_threshold) <= 255 else 254


                if sig_color_low_threshold.isnumeric():
                    Params.sig_color_low_threshold = int(
                        sig_color_low_threshold) if int(sig_color_low_threshold) >= 0 and int(sig_color_low_threshold) <= 255 else 2


                if sig_color_high_threshold.isnumeric():
                    Params.sig_color_high_threshold = int(
                        sig_color_high_threshold) if int(sig_color_high_threshold) >= 0 and int(sig_color_high_threshold) <= 255 else 254


                if color_low_threshold.isnumeric():
                    Params.color_low_threshold = int(
                        color_low_threshold) if int(color_low_threshold) >= 0 and int(color_low_threshold) <= 255 else -1


                if color_high_threshold.isnumeric():
                    Params.color_high_threshold = int(
                        color_high_threshold) if int(color_high_threshold) >= 0 and int(color_high_threshold) <= 255 else 255


                Params.visualize_skin = True if bool(
                    visualizeskintrue_sim) else False
                Params.visualize_landmarks = True if bool(
                    visualizeldmkstrue_sim) else False
                Params.visualize_patches = True if bool(
                    visualizepatchestrue_sim) else False
                Params.visualize_landmarks_number = True if bool(
                    visualizeldmksnumtrue_sim) else False

                try:
                    colorfont = ast.literal_eval(fontcolor)
                    if len(colorfont) == 4:
                        correct = True
                        for e in colorfont:
                            if not(e >= 0 and e <= 255):
                                correct = False
                        if correct:
                            Params.font_color = colorfont
                except:
                    pass

                if fontSize.isnumeric():
                    Params.font_size = float(
                        fontSize) if float(fontSize) > 0.0 else 0.3
                event = '-START-'
                

            if event == '-START-':
                bpm_plot = []
                bpm_save = []
                image = None
                sd = SharedData()
                if vhr_t == None:
                    vhr_t = threading.Thread(target=VHRroutine, args=(sd,framer))
                    vhr_t.daemon = False
                    vhr_t.start()
            
        
    def parse_cfg(self, configFilename):
        """ parses the given configuration file for loading the test's parameters.
        
        Args:
            configFilename: configuation file (.cfg) name of path .

        """

        self.parser = configparser.ConfigParser(inline_comment_prefixes=('#', ';'))
        self.parser.optionxform = str
        if not self.parser.read(configFilename):
            raise FileNotFoundError(configFilename)

        # load paramas
        self.datasetdict = dict(self.parser['DATASET'].items())
        self.sigdict = dict(self.parser['SIG'].items())
        self.bvpdict = dict(self.parser['BVP'].items())
        self.bpmdict = dict(self.parser['BPM'].items())

        # video idx list extraction
        if isinstance(ast.literal_eval(self.datasetdict['videoIdx']), list):
            self.videoIdx = [int(v) for v in ast.literal_eval(
                self.datasetdict['videoIdx'])]

        # load parameters for each methods
        self.methodsdict = {}
        self.methods = ast.literal_eval(self.bvpdict['methods'])
        for x in self.methods:
            self.methodsdict[x] = dict(self.parser[x].items())
